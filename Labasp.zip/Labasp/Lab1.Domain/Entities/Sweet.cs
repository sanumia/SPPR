using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab1.Domain.Entities
{
    public class Sweet
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public Category? CategoryId { get; set; }//может быть null
        public decimal Price { get; set; }
        public string? Image { get; set; }

        // MIME тип (image/jpeg, image/png, image/gif)
        public string ContentType { get; set; }

    }
}