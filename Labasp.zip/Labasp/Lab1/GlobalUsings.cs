global using Lab1.Domain.Entities;
global using Lab1.Domain.Models;
global using System;
global using System.Collections.Generic;
global using System.Linq;